import { Component, OnInit } from '@angular/core';

import {MovieService} from '../movie.service'
import { Movies } from '../movies';

@Component({
  selector: 'app-add-movies',
  templateUrl: './add-movies.component.html',
  styleUrls: ['./add-movies.component.css']
})
export class AddMoviesComponent implements OnInit {

movies:Movies[];
movie:Movies=new Movies();
movieNameMsg:String;
movieRatingMsg:String;
movieGenreMsg:String;
constructor(private movieService:MovieService) { }

 genre:String[]=["Drama","Fiction","Satire"];
  ngOnInit()
  {
    this.movies=this.movieService.getMovies();
  }
   addMovie(data):void
   {
      this.movie.name = data.name;
      this.movie.rating = data.rating;
      this.movie.genre = data.genre;
      if(!data.name)
      {
       this.movieNameMsg='Movie Name is required!!';
      }
      else
        this.movieNameMsg=null;
      if(!data.rating)
      {
       this.movieRatingMsg='Movie Rating is required!!';
      }
      else
      this.movieRatingMsg=null;
      if(!data.genre)
      {
       this.movieGenreMsg='Movie Genre is required!!';
      }
      else
       this.movieGenreMsg=null;
       if(data.rating && data.name && data.genre)
       {
      alert(`Name: ${data.name} Rating: ${data.rating} Genre: ${data.genre}`);
      console.log(this.movie);
      this.movieService.addMovie(this.movie);
      
       }
   }
}
