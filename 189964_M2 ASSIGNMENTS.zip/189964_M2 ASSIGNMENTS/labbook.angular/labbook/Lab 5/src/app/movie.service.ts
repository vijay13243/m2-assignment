import { Injectable } from '@angular/core';
import {movies} from './movieDetails';
import { Movies } from './movies';
@Injectable({
  providedIn: 'root'
})
export class MovieService {
  moviesbyGenre:Array<Movies>;

  constructor() { }
  getMovies():Movies[]
  {
   return movies;
  }
  addMovie(movie:Movies)
  {
    movies.push(movie);
  }
  searchMovie(genre:String):Movies[]
  { 
    this.moviesbyGenre=[];
    for (let i of movies) {
      if(i.genre === genre)
       this.moviesbyGenre.push(i);
    }
     return this.moviesbyGenre;
  }
}
