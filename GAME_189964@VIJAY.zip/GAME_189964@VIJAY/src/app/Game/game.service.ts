import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { Gamelist } from './game.interface';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  game: Gamelist[];

  cardBalance: number = 600;

  constructor(private http: HttpClient) {
    this.populateGamelist().subscribe(data => this.game = data, error => console.log(error));
  }

  populateGamelist(): Observable<Gamelist[]> {
    return this.http.get<Gamelist[]>("../../assets/GameList.json");
  }

  getGames(): Gamelist[] {
    return this.game;
  }

  getCardBalance(rate: number): number {
    this.cardBalance = this.cardBalance - rate;
    return this.cardBalance;
  }
}
