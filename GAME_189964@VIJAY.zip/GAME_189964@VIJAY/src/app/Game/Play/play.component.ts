import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';
import { Router } from '../../../../node_modules/@angular/router';
import { Gamelist } from '../game.interface';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {


  game: Gamelist[];
  cardBalance: number = 600;
  constructor(private Service: GameService, private router: Router) { }

  ngOnInit() {
    this.game = this.Service.getGames();
    console.log(this.game);
  }

}
