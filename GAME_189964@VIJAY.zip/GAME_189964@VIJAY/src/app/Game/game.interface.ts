export interface Gamelist {
    gameId: number;
    gameName: string;
    gamePrice: number;
}