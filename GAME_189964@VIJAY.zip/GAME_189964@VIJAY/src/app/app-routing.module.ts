import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlayComponent } from './Game/Play/play.component';
import { SuccessComponent } from './Game/Success/success.component';
import { DummyComponent } from './Dummy/dummy.component';


const routes: Routes = [
  {path:"play", component:PlayComponent},
  {path:"success/:id", component:SuccessComponent},
  {path:'', component:DummyComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
